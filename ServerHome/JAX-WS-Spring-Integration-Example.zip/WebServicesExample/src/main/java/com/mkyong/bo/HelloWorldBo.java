package com.mkyong.bo;

public interface HelloWorldBo{

	String getHelloWorld();
	
}