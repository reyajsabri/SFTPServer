package com.mkyong.bo.impl;

import com.mkyong.bo.HelloWorldBo;

public class HelloWorldBoImpl implements HelloWorldBo{

	public String getHelloWorld(){
		return "JAX-WS + Spring!";
	}
	
}