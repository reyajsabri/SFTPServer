# LEGACY REPOSITORY

This is now a legacy repository for AdoptOpenJDK's earlier OpenJDK9 releases.  Please see [here](https://github.com/AdoptOpenJDK/openjdk9-binaries/releases) going forwards.

# Releases

This (legacy) repository is for publishing all of the tagged releases which match releases from OpenJDK proper (http://openjdk.java.net).

These binaries are built on a shared CI infrastructure (see http://ci.adoptopenjdk.net) using an openly shared build tool chain (see https://github.com/AdoptOpenJDK/openjdk-build)

## How to get involved

Join the mailing list at: http://mail.openjdk.java.net/mailman/listinfo/adoption-discuss  
Join the Slack at: https://www.adoptopenjdk.net/slack.html
