/**
 * Annotations for java based configuration of listeners.
 *
 * @author Michael Minella
 */
package org.springframework.batch.core.annotation;