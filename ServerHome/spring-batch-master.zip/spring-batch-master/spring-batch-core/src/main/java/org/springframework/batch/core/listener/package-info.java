/**
 * Generic implementations of core batch listener interfaces.
 *
 * @author Michael Minella
 * @author Mahmoud Ben Hassine
 */
@NonNullApi
package org.springframework.batch.core.listener;

import org.springframework.lang.NonNullApi;
