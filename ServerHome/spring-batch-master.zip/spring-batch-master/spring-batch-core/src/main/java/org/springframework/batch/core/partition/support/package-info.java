/**
 * Implementation of common partition components.
 *
 * @author Michael Minella
 * @author Mahmoud Ben Hassine
 */
@NonNullApi
package org.springframework.batch.core.partition.support;

import org.springframework.lang.NonNullApi;
