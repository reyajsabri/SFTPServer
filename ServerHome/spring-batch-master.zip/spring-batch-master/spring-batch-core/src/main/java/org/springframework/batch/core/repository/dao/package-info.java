/**
 * Specific implementations of dao concerns.
 *
 * @author Michael Minella
 * @author Mahmoud Ben Hassine
 */
@NonNullApi
package org.springframework.batch.core.repository.dao;

import org.springframework.lang.NonNullApi;
