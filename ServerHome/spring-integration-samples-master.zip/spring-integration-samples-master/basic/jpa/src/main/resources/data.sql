insert into PEOPLE(id, name, CREATED_DATE_TIME) values ('1001', 'Cartman', NOW());
